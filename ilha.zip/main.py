#!/usr/bin/env python3

from ilha import Ilha

if __name__ == "__main__":
    instancia = Ilha("normal", 4)
    instancia.setup()
    instancia.start()
